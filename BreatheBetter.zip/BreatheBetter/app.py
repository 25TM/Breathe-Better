import streamlit as st
import pandas as pd
from fpdf import FPDF
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from datetime import datetime

# Define PDF structure
class PDF(FPDF):
    def header(self):
        self.set_font("Arial", "B", 12)
        self.cell(0, 10, "Pollution Report", ln=True, align="C")
        self.ln(10)

    def footer(self):
        self.set_y(-15)
        self.set_font("Arial", "I", 8)
        self.cell(0, 10, f"Page {self.page_no()}", 0, 0, "C")

    def chapter_title(self, title):
        self.set_font("Arial", "B", 12)
        self.cell(0, 10, f"{title}", ln=True)
        self.ln(5)

    def chapter_body(self, body):
        self.set_font("Arial", "", 12)
        self.multi_cell(0, 10, body)
        self.ln(5)

# Function to generate PDF report
def generate_pdf(dataframe, output_path):
    report_summary = dataframe.groupby("Pollutant")["Pollutant Level (µg/m³)"].describe()

    pdf = PDF()
    pdf.add_page()

    pdf.chapter_title("Executive Summary")
    pdf.chapter_body("This report provides a summary of weather pollution data collected from the provided dataset.")

    pdf.chapter_title("Introduction")
    pdf.chapter_body("This report analyzes air pollution data, capturing different pollutants' daily levels. The report's purpose is to provide insights on air quality and potential measures to address pollution.")

    pdf.chapter_title("Body")
    pdf.chapter_body("Below is the summary of pollution data:\n")
    for pollutant, data in report_summary.iterrows():
        pdf.chapter_body(f"{pollutant}: Mean={data['mean']:.2f} µg/m³, Max={data['max']:.2f} µg/m³")

    pdf.chapter_title("Conclusion")
    pdf.chapter_body("This analysis shows fluctuating pollution levels across various pollutants. Further measures can include pollution monitoring and alert systems to mitigate pollution impacts.")

    pdf.output(output_path)
    return output_path

# Function to send email
def send_email(sender_email, sender_password, receiver_email, pdf_path):
    subject = "Weather Pollution Report - Data Analysis"
    body = """
    Dear Authorizer,

    Please find attached the weather pollution report based on the provided dataset.
    This report provides detailed insights into pollution levels and suggested precautions.

    Best regards,
    Streamlit App Team
    """

    # Create email message
    message = MIMEMultipart()
    message["From"] = sender_email
    message["To"] = receiver_email
    message["Subject"] = subject
    message.attach(MIMEText(body, "plain"))

    # Attach PDF
    with open(pdf_path, "rb") as file:
        attach = MIMEApplication(file.read(), _subtype="pdf")
        attach.add_header("Content-Disposition", "attachment", filename="Weather_Pollution_Report.pdf")
        message.attach(attach)

    # Send email
    try:
        with smtplib.SMTP("smtp.gmail.com", 587) as server:
            server.starttls()
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, receiver_email, message.as_string())
            return "Email sent successfully."
    except smtplib.SMTPException as e:
        return f"An error occurred: {e}"

# Streamlit App
st.title("BREATH BETTER")

# Hardcoded file path for dataset
file_path = "C:/Users/manoy/Downloads/BreatheBetter/preprocessed_data_with_averages_v2.xlsx"

try:
    df = pd.read_excel(file_path)
    st.write("File loaded successfully. Sample data:")
    st.write(df.head())

    # Transform data for report
    df['Date'] = pd.to_datetime('2024-11-01')  # Assign default date if not available
    df['Pollutant'] = df['category']          # Map 'category' to 'Pollutant'
    df['Region'] = 'Default Region'           # Assign a default region
    df['Pollutant Level (µg/m³)'] = df['co']  # Map 'co' to 'Pollutant Level (µg/m³)'
    required_columns = ["Date", "Pollutant", "Region", "Pollutant Level (µg/m³)"]
    df = df[required_columns]

    # Generate PDF
    if st.button("Generate Report"):
        output_path = "C:/Users/manoy/Downloads/BreatheBetter/Weather_Pollution_Report.pdf"
        generate_pdf(df, output_path)
        st.success(f"Report generated and saved to {output_path}.")
        st.write("Download your report [here](file:///" + output_path.replace("\\", "/") + ").")

    # Email functionality
    st.subheader("Email the Report")
    sender_email = st.text_input("Sender Email")
    sender_password = st.text_input("Sender Email Password", type="password")
    receiver_email = st.text_input("Recipient Email")
    if st.button("Send Email"):
        if sender_email and sender_password and receiver_email:
            email_status = send_email(sender_email, sender_password, receiver_email, output_path)
            st.success(email_status)
        else:
            st.error("Please fill in all email fields.")
except FileNotFoundError:
    st.error(f"File not found at {file_path}. Please check the path.")
